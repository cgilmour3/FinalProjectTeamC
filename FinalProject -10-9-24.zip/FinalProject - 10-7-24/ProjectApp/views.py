from django.shortcuts import render, get_object_or_404, redirect
from .models import Patient, Doctor
from .forms import PatientForm, DoctorForm

# Create your views here.
# Home page view
def index(request):
    return render(request, 'index.html')

# Patients page view
def patients(request):
    patients = Patient.objects.all()
    return render(request, 'patients.html', {'patients': patients})

# Add new patient view
def add_patient(request):
    if request.method == 'POST':
        form = PatientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('patients')
    else:
        form = PatientForm()
    return render(request, 'add_patient.html', {'form': form})

# Doctors page view
def doctors(request):
    doctors = Doctor.objects.all()
    return render(request, 'doctors.html', {'doctors': doctors})

# Add new doctor view
def add_doctor(request):
    if request.method == 'POST':
        form = DoctorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('doctors')
    else:
        form = DoctorForm()
    return render(request, 'add_doctor.html', {'form': form})
