from django import forms
from .models import Patient, Doctor

class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = ['patient_fname', 'patient_lname', 'patient_age', 'patient_gender', 'patient_doctor']

class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = ['doctor_fname', 'doctor_lname', 'doctor_specialty']
